<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class ArixMailController extends Controller
{
    public function __construct(
        private ViewFactory $view,
        private SettingsRepositoryInterface $settings,
        private AlertsMessageBag $alert
    ) {
    }

    public function index()
    {
        return $this->view->make('admin.arix.mail', [
            'mail_color' => $this->settings->get('arix:mail_color', '#000000'),
            'mail_backgroundColor' => $this->settings->get('arix:mail_backgroundColor', '#ffffff'),
            'mail_logo' => $this->settings->get('arix:mail_logo', ''),
            'mail_logoFull' => $this->settings->get('arix:mail_logoFull', 'false'),
            'mail_mode' => $this->settings->get('arix:mail_mode', 'dark'),
            'mail_discord' => $this->settings->get('arix:mail_discord', ''),
            'mail_twitter' => $this->settings->get('arix:mail_twitter', ''),
            'mail_facebook' => $this->settings->get('arix:mail_facebook', ''),
            'mail_instagram' => $this->settings->get('arix:mail_instagram', ''),
            'mail_linkedin' => $this->settings->get('arix:mail_linkedin', ''),
            'mail_youtube' => $this->settings->get('arix:mail_youtube', ''),
            'mail_status' => $this->settings->get('arix:mail_status', ''),
            'mail_billing' => $this->settings->get('arix:mail_billing', ''),
            'mail_support' => $this->settings->get('arix:mail_support', ''),
        ]);
    }

    public function store(Request $request)
    {
        foreach ($request->except('_token') as $key => $value) {
            if (str_starts_with($key, 'arix:')) {
                $this->settings->set($key, $value ?? '');
            }
        }

        $this->alert->success('Mail settings have been updated.')->flash();
        return Redirect::route('admin.arix.mail');
    }
}
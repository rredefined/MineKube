<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Pterodactyl\Models\Egg;
use Pterodactyl\Models\User;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\DB;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Repositories\Eloquent\ServerVariableRepository;
use Pterodactyl\Services\Servers\ReinstallServerService;
use Pterodactyl\Services\Servers\StartupModificationService;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Http\Requests\Api\Client\Servers\EggChangerRequest;

class EggChangerController extends ClientApiController
{
    /**
     * @var \Pterodactyl\Services\Servers\StartupModificationService
     */
    protected $startupModificationService;

    /**
     * @var \Pterodactyl\Services\Servers\ReinstallServerService
     */
    protected $reinstallServerService;

    /**
     * @var \Pterodactyl\Repositories\Eloquent\ServerVariableRepository
     */
    protected $serverVariableRepository;

    /**
     * EggChangerController constructor.
     */
    public function __construct(
        StartupModificationService $startupModificationService,
        ReinstallServerService $reinstallServerService,
        ServerVariableRepository $serverVariableRepository
    ) {
        parent::__construct();

        $this->startupModificationService = $startupModificationService;
        $this->reinstallServerService = $reinstallServerService;
        $this->serverVariableRepository = $serverVariableRepository;
    }

    /**
     * @param EggChangerRequest $request
     * @param Server $server
     * @return array
     */
    public function index(EggChangerRequest $request, Server $server)
    {
        $selectable_eggs = [];
        
        // Cek apakah available_eggs valid array/serialized
        $availableList = @unserialize($server->available_eggs);
        if ($availableList === false) {
            $availableList = [];
        }

        foreach ($availableList as $item) {
            // Ambil kolom thumbnail dan image (Arix) sekaligus
            $egg = DB::table('eggs')
                ->select(['id', 'name', 'thumbnail', 'image'])
                ->where('id', '=', $item)
                ->first();

            if ($egg) {
                // LOGIC PINTAR: 
                // Kalau kolom 'thumbnail' kosong, cek kolom 'image' punya Arix
                if (empty($egg->thumbnail) && !empty($egg->image)) {
                    $egg->thumbnail = $egg->image;
                }
                
                // Hapus field image biar output JSON tetap bersih dan standar
                unset($egg->image);

                array_push($selectable_eggs, $egg);
            }
        }

        return [
            'success' => true,
            'data' => [
                'eggs' => $selectable_eggs,
                'currentEggId' => $server->egg_id,
            ],
        ];
    }

    /**
     * @param EggChangerRequest $request
     * @param Server $server
     * @return array
     * @throws DisplayException
     * @throws \Illuminate\Validation\ValidationException
     */
    public function change(EggChangerRequest $request, Server $server)
    {
        $this->validate($request, [
            'eggId' => 'required|integer',
        ]);

        $eggId = (int) $request->input('eggId');
        $reinstallServer = (bool) $request->input('reinstallServer', false);

        // Gunakan Model Eloquent biar bisa akses relasi variables
        $newEgg = Egg::find($eggId);
        if (!$newEgg) {
            throw new DisplayException('Egg not found.');
        }

        // Validasi ketersediaan Egg buat server ini
        $availableList = @unserialize($server->available_eggs);
        if ($availableList === false || !in_array($eggId, $availableList)) {
            throw new DisplayException('This egg isn\'t available to this server.');
        }

        // FIX START: Reset Variables Logic
        DB::beginTransaction();
        try {
            // 1. Hapus variable lama yang nempel di server (biar gak konflik)
            $this->serverVariableRepository->deleteWhere(['server_id' => $server->id]);

            // 2. Ambil variable default dari Egg tujuan
            $newVariables = $newEgg->variables;
            
            // 3. Masukin variable baru ke server
            foreach ($newVariables as $variable) {
                $this->serverVariableRepository->create([
                    'server_id' => $server->id,
                    'variable_id' => $variable->id,
                    'variable_value' => $variable->default_value ?? '',
                ]);
            }

            // 4. Update Config Server (Egg, Nest, Startup, Image)
            $this->startupModificationService->setUserLevel(User::USER_LEVEL_ADMIN);
            
            // Ambil docker image pertama dari array
            $dockerImages = $newEgg->docker_images;
            $firstImage = is_array($dockerImages) ? reset($dockerImages) : $dockerImages;

            $this->startupModificationService->handle($server, [
                'nest_id' => $newEgg->nest_id,
                'egg_id' => $newEgg->id,
                'docker_image' => $firstImage,
                'startup' => $newEgg->startup,
            ]);

            DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();
            // Log error aslinya buat debugging kalau masih error
            \Illuminate\Support\Facades\Log::error($e);
            throw new DisplayException('Failed to change the egg: ' . $e->getMessage());
        }
        // FIX END

        if ($reinstallServer) {
            try {
                $this->reinstallServerService->handle($server);
            } catch (\Throwable $e) {
                throw new DisplayException('Egg was changed, but failed to trigger server reinstall.');
            }
        }

        return [
            'success' => true,
            'data' => [],
        ];
    }
}
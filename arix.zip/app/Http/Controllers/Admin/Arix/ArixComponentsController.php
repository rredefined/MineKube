<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class ArixComponentsController extends Controller
{
    public function __construct(
        private ViewFactory $view,
        private SettingsRepositoryInterface $settings,
        private AlertsMessageBag $alert
    ) {
    }

    public function index()
    {
        return $this->view->make('admin.arix.components', [
            'serverRow' => $this->settings->get('arix:serverRow', '1'),
            'socialButtons' => $this->settings->get('arix:socialButtons', 'false'),
            'discordBox' => $this->settings->get('arix:discordBox', 'false'),
            'statsCards' => $this->settings->get('arix:statsCards', '1'),
            'sideGraphs' => $this->settings->get('arix:sideGraphs', '1'),
            'graphs' => $this->settings->get('arix:graphs', '1'),
            'slot1' => $this->settings->get('arix:slot1', 'disabled'),
            'slot2' => $this->settings->get('arix:slot2', 'disabled'),
            'slot3' => $this->settings->get('arix:slot3', 'disabled'),
            'slot4' => $this->settings->get('arix:slot4', 'disabled'),
            'slot5' => $this->settings->get('arix:slot5', 'disabled'),
            'slot6' => $this->settings->get('arix:slot6', 'disabled'),
            'slot7' => $this->settings->get('arix:slot7', 'disabled'),
        ]);
    }

    public function store(Request $request)
    {
        foreach ($request->except('_token') as $key => $value) {
            if (str_starts_with($key, 'arix:')) {
                $this->settings->set($key, $value ?? 'disabled');
            }
        }

        $this->alert->success('Components settings have been updated.')->flash();
        return Redirect::route('admin.arix.components');
    }
}
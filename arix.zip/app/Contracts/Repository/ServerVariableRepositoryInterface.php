<?php

namespace Pterodactyl\Contracts\Repository;

interface ServerVariableRepositoryInterface extends RepositoryInterface
{
}

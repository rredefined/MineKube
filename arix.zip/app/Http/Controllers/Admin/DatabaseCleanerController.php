<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\View\Factory as ViewFactory;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema; // <--- INI YANG KETINGGALAN TADI
use Pterodactyl\Http\Controllers\Controller;

class DatabaseCleanerController extends Controller
{
    public function __construct(
        private ViewFactory $view
    ) {}

    /**
     * Tampilkan Halaman
     */
    public function index(): View
    {
        return $this->view->make('admin.databasecleaner');
    }

    /**
     * Proses Pembersihan (Clean)
     */
    public function clean(Request $request)
    {
        // Validasi Input
        $validated = $request->validate([
            'tables'    => 'required|array',
            'tables.*'  => 'in:activity_logs,api_logs,audit_logs,failed_jobs',
            'timestamp' => 'required_without:quick|nullable|date',
            'quick'     => 'nullable|in:7,14,30,90,180,365'
        ]);

        // Tentukan batas waktu (Cutoff)
        if ($request->has('quick')) {
            $days = (int)$validated['quick'];
            $mysqlTimestamp = now()->subDays($days)->format('Y-m-d H:i:s');
        } else {
            $rawTimestamp = $validated['timestamp'];
            $mysqlTimestamp = date('Y-m-d H:i:s', strtotime($rawTimestamp));
        }

        // Mapping kolom tanggal di database
        $columnsMapping = [
            'activity_logs' => 'timestamp',
            'api_logs'      => 'created_at',
            'audit_logs'    => 'created_at',
            'failed_jobs'   => 'failed_at',
        ];

        // Cek struktur tabel activity_logs (jaga-jaga beda versi)
        if(Schema::hasColumn('activity_logs', 'timestamp')) {
             $columnsMapping['activity_logs'] = 'timestamp';
        } else {
             $columnsMapping['activity_logs'] = 'created_at';
        }

        $deletedRecords = [];

        try {
            foreach ($validated['tables'] as $table) {
                $dateColumn = $columnsMapping[$table] ?? 'created_at';

                // Cek kolom beneran ada gak biar gak error
                if (!Schema::hasColumn($table, $dateColumn)) {
                    continue; 
                }

                $deleted = DB::table($table)
                    ->where($dateColumn, '<', $mysqlTimestamp)
                    ->delete();
                $deletedRecords[$table] = $deleted;
            }

            // Bikin pesan sukses
            $msgParts = [];
            foreach ($deletedRecords as $table => $count) {
                $msgParts[] = "{$table}: {$count} deleted";
            }
            $message = "Success! " . implode(", ", $msgParts);

            return redirect()->back()->with('success', $message);

        } catch (\Exception $e) {
            \Log::error('Purge error: ' . $e->getMessage());
            return redirect()->back()->withErrors(['error' => 'An error occurred: ' . $e->getMessage()]);
        }
    }
}
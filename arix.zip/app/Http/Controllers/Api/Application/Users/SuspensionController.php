<?php

namespace Pterodactyl\Http\Controllers\Api\Application\Users;

use Pterodactyl\Models\User;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Pterodactyl\Services\Servers\SuspensionService;
use Pterodactyl\Http\Requests\Api\Application\Users\DeleteUserRequest;
use Pterodactyl\Http\Controllers\Api\Application\ApplicationApiController;

class SuspensionController extends ApplicationApiController
{
    /**
     * @var SuspensionService
     */
    protected $suspensionService;

    /**
     * SuspensionController constructor.
     * @param SuspensionService $suspensionService
     */
    public function __construct(SuspensionService $suspensionService)
    {
        parent::__construct();

        $this->suspensionService = $suspensionService;
    }

    /**
     * @param DeleteUserRequest $request
     * @param User $user
     * @return array|bool[]
     */
    public function toggleSuspension(DeleteUserRequest $request, User $user): array
    {
        try {
            $this->validate($request, [
                'is_suspended' => 'required|int|min:0|max:1',
                'suspend_cause' => 'max:191',
            ]);
        } catch (ValidationException $e) {
            return ['success' => false, 'error' => 'Invalid / missing parameters. Required parameters: is_suspended, suspend_cause'];
        }

        $servers = DB::table('servers')->where('owner_id', '=', $user->id)->get();
        foreach ($servers as $server) {
            try {
                $this->suspensionService->toggle(Server::find($server->id), ((int) $request->input('is_suspended', 0) == 0 ? SuspensionService::ACTION_UNSUSPEND : SuspensionService::ACTION_SUSPEND));
            } catch (\Throwable $e) {
                return ['success' => false, 'error' => 'Failed to suspend / unsuspend a server. Please try again...'];
            }
        }

        DB::table('users')->where('id', '=', $user->id)->update([
            'is_suspended' => (int) $request->input('is_suspended', 0),
            'suspend_cause' => ((int) $request->input('is_suspended', 0) == 0 ? null : trim($request->input('suspend_cause', ''))),
        ]);

        return ['success' => true];
    }
}

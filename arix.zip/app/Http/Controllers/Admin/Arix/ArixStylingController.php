<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class ArixStylingController extends Controller
{
    public function __construct(
        private ViewFactory $view,
        private SettingsRepositoryInterface $settings,
        private AlertsMessageBag $alert
    ) {
    }

    public function index()
    {
        return $this->view->make('admin.arix.styling', [
            'pageTitle' => $this->settings->get('arix:pageTitle', 'true'),
            'flashMessage' => $this->settings->get('arix:flashMessage', '1'),
            'backgroundImage' => $this->settings->get('arix:backgroundImage', ''),
            'backgroundImageLight' => $this->settings->get('arix:backgroundImageLight', ''),
            'loginBackground' => $this->settings->get('arix:loginBackground', ''),
            'loginGradient' => $this->settings->get('arix:loginGradient', 'false'),
            'backdrop' => $this->settings->get('arix:backdrop', 'false'),
            'backdropPercentage' => $this->settings->get('arix:backdropPercentage', ''),
            'defaultMode' => $this->settings->get('arix:defaultMode', 'darkmode'),
            'radiusInput' => $this->settings->get('arix:radiusInput', ''),
            'radiusBox' => $this->settings->get('arix:radiusBox', ''),
            'borderInput' => $this->settings->get('arix:borderInput', 'false'),
            'copyright' => $this->settings->get('arix:copyright', ''),
        ]);
    }

    public function store(Request $request)
    {
        foreach ($request->except('_token') as $key => $value) {
            if (str_starts_with($key, 'arix:')) {
                $this->settings->set($key, $value ?? '');
            }
        }

        $this->alert->success('Styling settings have been updated.')->flash();
        return Redirect::route('admin.arix.styling');
    }
}
<?php

namespace Pterodactyl\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Routing\ResponseFactory;

class IsSuspended
{
    /**
     * @var ResponseFactory
     */
    protected $responseFactory;

    /**
     * IsSuspended constructor.
     * @param ResponseFactory $responseFactory
     */
    public function __construct(ResponseFactory $responseFactory)
    {
        $this->responseFactory = $responseFactory;
    }

    /**
     * Handle an incoming request.
     *
     * @return mixed
     *
     * @throws \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException
     */
    public function handle(Request $request, Closure $next)
    {
        if (!$request->user()) {
            return redirect()->to('/auth/login');
        }

        if ($request->user()->is_suspended != 0) {
            return $this->responseFactory->view('partials.suspended', [
                'reason' => $request->user()->suspend_cause ?? '',
            ]);
        }

        return $next($request);
    }
}

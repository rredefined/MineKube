<?php

namespace Pterodactyl\Console\Commands\Schedule;

use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class AutoSuspension extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'p:billing:auto-suspension';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Automatically checks if there are servers that have to be suspended due to billing.';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // Fix Date Format: Gunakan Carbon biar akurat (Y-m-d H:i:s)
        // Script lama pake 'h:m:s' itu salah (h=12jam, m=bulan), harusnya 'H:i:s'
        $now = Carbon::now()->toDateTimeString();

        // --- OPTIMASI ---
        // Daripada nge-loop satu-satu (bikin log error), mending langsung update via SQL.
        // Ini lebih cepat, hemat resource, dan anti error "Undefined property".

        // 1. SUSPEND: Server yang masa aktifnya habis
        DB::table('servers')
            ->where('suspended', 0) // Cari yang masih aktif
            ->where('renewal_date', '<', $now) // Yang tanggalnya udah lewat
            ->where('renewal_date', '!=', '0000-00-00 00:00:00') // Abaikan yang permanen
            ->whereNotNull('renewal_date') // Pastikan tanggalnya ada
            ->update(['suspended' => 1]);

        // 2. UNSUSPEND: Server yang sudah diperpanjang
        DB::table('servers')
            ->where('suspended', 1) // Cari yang sedang disuspend
            ->where(function ($query) use ($now) {
                $query->where('renewal_date', '>', $now) // Yang tanggalnya masa depan
                      ->orWhere('renewal_date', '=', '0000-00-00 00:00:00'); // Atau yang permanen
            })
            ->update(['suspended' => 0]);

        $this->info('Billing Auto-Suspension check completed successfully.');
    }
}
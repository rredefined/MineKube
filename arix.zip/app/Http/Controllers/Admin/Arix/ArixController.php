<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class ArixController extends Controller
{
    public function __construct(
        private ViewFactory $view,
        private SettingsRepositoryInterface $settings,
        private AlertsMessageBag $alert
    ) {
    }

    public function index()
    {
        return $this->view->make('admin.arix.index', [
            'logo' => $this->settings->get('arix:logo', ''),
            'logoHeight' => $this->settings->get('arix:logoHeight', '100px'),
            'fullLogo' => $this->settings->get('arix:fullLogo', 'false'),
            'discord' => $this->settings->get('arix:discord', ''),
            'support' => $this->settings->get('arix:support', ''),
            'status' => $this->settings->get('arix:status', ''),
            'billing' => $this->settings->get('arix:billing', ''),
        ]);
    }

    public function store(Request $request)
    {
        foreach ($request->except('_token') as $key => $value) {
            if (str_starts_with($key, 'arix:')) {
                $this->settings->set($key, $value ?? '');
            }
        }

        $this->alert->success('General settings have been updated.')->flash();
        return Redirect::route('admin.arix');
    }
}
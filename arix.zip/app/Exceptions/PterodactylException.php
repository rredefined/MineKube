<?php

namespace Pterodactyl\Exceptions;

class PterodactylException extends \Exception
{
}
